<section class="sec-product-detail bg0 p-t-65 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-7 p-b-30">
					<div class="p-l-25 p-r-30 p-lr-0-lg">
						<div class="wrap-slick3 flex-sb flex-w">
							<div class="wrap-slick3-dots"></div>
							<div class="wrap-slick3-arrows flex-sb-m flex-w"></div>
                                  <!--PHOTO SILDE-->
							<div class="slick3 gallery-lb">
								<div class="item-slick3" data-thumb="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg">
									<div class="wrap-pic-w pos-relative">
										<img src="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg" alt="IMG-PRODUCT">

										<a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04" href="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg">
											<i class="fa fa-expand"></i>
										</a>
									</div>
								</div>

								<div class="item-slick3" data-thumb="<?php echo e(asset('frontEnd')); ?>/images/CETATEST02.jpg">
									<div class="wrap-pic-w pos-relative">
										<img src="<?php echo e(asset('frontEnd')); ?>/images/CETATEST02.jpg" alt="IMG-PRODUCT">

										<a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04" href="<?php echo e(asset('frontEnd')); ?>/images/CETATEST02.jpg">
											<i class="fa fa-expand"></i>
										</a>
									</div>
								</div>

								<div class="item-slick3" data-thumb="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg">
									<div class="wrap-pic-w pos-relative">
										<img src="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg" alt="IMG-PRODUCT">

										<a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04" href="<?php echo e(asset('frontEnd')); ?>/images/CETATEST01.jpg">
											<i class="fa fa-expand"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					<!--PHOTO SILDE-->


				<div class="col-md-6 col-lg-5 p-b-30">
					<div class="p-r-50 p-t-5 p-lr-0-lg">
						<h4 class="mtext-105 cl2 js-name-detail p-b-14">
							Leak tester CETATEST 825 - New!
						</h4>

						<span class="mtext-106 cl2">

						</span>

						<p class="stext-102 cl3 p-t-23">
							The CETATEST 825 is the fourth generation of CETA differential pressure testers.

                            The differential pressure leak test is based on the comparison of the pressures in the test part volume with the pressure in a tight reference volume.
                            It can be used for fully automatic leak test processes within the cycle time of the production line.

                            The integrated 7-inch touch-screen with an intuitive operable graphical user interface makes it possible to display a wide range of information (for example, measurement curves, histograms).
                            Operation is possible both via the touch-screen and via a dual-jog dial. Separate start / stop buttons ensure operating safety even in harsh industrial environments.
						</p>

						<!--  -->
						<div class="p-t-33">
							<div class="flex-w flex-r-m p-b-10">
								<div class="size-203 flex-c-m respon6">
									Size
								</div>

								<div class="size-204 respon6-next">
									<div class="rs1-select2 bor8 bg0">

										<select class="js-select2" name="time">
											<option>Choose an option</option>
											<option>Size S</option>
											<option>Size M</option>
											<option>Size L</option>
											<option>Size XL</option>
										</select>
										<div class="dropDownSelect2"></div>
									</div>
								</div>
							</div>

							<div class="flex-w flex-r-m p-b-10">
								<div class="size-203 flex-c-m respon6">
									Color
								</div>

								<div class="size-204 respon6-next">
									<div class="rs1-select2 bor8 bg0">
										<select class="js-select2" name="time">
											<option>Choose an option</option>
											<option>Red</option>
											<option>Blue</option>
											<option>White</option>
											<option>Grey</option>
										</select>
										<div class="dropDownSelect2"></div>
									</div>
								</div>
							</div>

							<div class="flex-w flex-r-m p-b-10">
								<div class="size-204 flex-w flex-m respon6-next">
									<div class="wrap-num-product flex-w m-r-20 m-tb-10">
										<div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
											<i class="fs-16 zmdi zmdi-minus"></i>
										</div>

										<input class="mtext-104 cl3 txt-center num-product" type="number" name="num-product" value="1">

										<div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
											<i class="fs-16 zmdi zmdi-plus"></i>
										</div>
									</div>

									<button class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 js-addcart-detail">
										Add to cart
									</button>
								</div>
							</div>
						</div>
                        </div>
					</div>
				</div>
			</div>
<?php /**PATH C:\Users\fangritlong\Desktop\Aizen\www2\resources\views/filepropro/bodyfor_showdetail.blade.php ENDPATH**/ ?>