<!DOCTYPE html>
<html lang="en">
<head >
	<title>Product Detail</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $__env->yieldContent('css_js'); ?>
</head>
<body class="animsition" >
<?php echo $__env->make('filepropro.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</header>

<?php echo $__env->make('filepropro.breadC', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('filepropro.bodyfor_showdetail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	

			<div class="bor10 m-t-50 p-t-43 p-b-40">
				<!-- Tab01 -->
				<div class="tab01">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item p-b-10">
							<a class="nav-link active" data-toggle="tab" href="#description" role="tab">Description</a>
						</li>

						<li class="nav-item p-b-10">
							<a class="nav-link" data-toggle="tab" href="#information" role="tab">Additional information</a>
						</li>


					</ul>

					<!-- Tab panes -->
					<div class="tab-content p-t-43">
						<!-- - -->
						<div class="tab-pane fade show active" id="description" role="tabpanel">
							<div class="how-pos2 p-lr-15-md">
								<p class="stext-102 cl6">
									Aenean sit amet gravida nisi. Nam fermentum est felis, quis feugiat nunc fringilla sit amet. Ut in blandit ipsum. Quisque luctus dui at ante aliquet, in hendrerit lectus interdum. Morbi elementum sapien rhoncus pretium maximus. Nulla lectus enim, cursus et elementum sed, sodales vitae eros. Ut ex quam, porta consequat interdum in, faucibus eu velit. Quisque rhoncus ex ac libero varius molestie. Aenean tempor sit amet orci nec iaculis. Cras sit amet nulla libero. Curabitur dignissim, nunc nec laoreet consequat, purus nunc porta lacus, vel efficitur tellus augue in ipsum. Cras in arcu sed metus rutrum iaculis. Nulla non tempor erat. Duis in egestas nunc.
								</p>
							</div>
						</div>

						<!-- - -->
						<div class="tab-pane fade" id="information" role="tabpanel">
						<div class="how-pos2 p-lr-15-md">
								<p class="stext-102 cl6">
						The CETATEST 825 is the fourth generation of CETA differential pressure testers.

The differential pressure leak test is based on the comparison of the pressures in the test part volume with the pressure in a tight reference volume.
It can be used for fully automatic leak test processes within the cycle time of the production line.

The integrated 7-inch touch-screen with an intuitive operable graphical user interface makes it possible to display a wide range of information (for example, measurement curves, histograms).
Operation is possible both via the touch-screen and via a dual-jog dial. Separate start / stop buttons ensure operating safety even in harsh industrial environments.
</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="bg6 flex-c-m flex-w size-302 m-t-73 p-tb-15">
			<span class="stext-107 cl6 p-lr-25">
				Name : ttop
			</span>

			<span class="stext-107 cl6 p-lr-25">
				top top top
			</span>
		</div>
	</section>

	<footer class="bg3 p-t-75 p-b-32">


				<p class="stext-107 cl6 txt-center">

                Create By Top &copy;<script>document.write(new Date().getFullYear());</script>


				</p>

	</footer>


	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>

	<!-- Modal1 -->

<?php echo $__env->make('filepropro.jsScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
	

</html>
<?php /**PATH /Users/zero/Desktop/Internship/TEST-master/www2/resources/views/popo.blade.php ENDPATH**/ ?>