
<header class="header-v4" >
		<!-- Header desktop -->
		<div class="container-menu-desktop">

			<div class="wrap-menu-desktop how-shadow1">
				<nav class="limiter-menu-desktop container">

					<!-- Logo desktop -->
					<a href="<?php echo e(asset('frontEnd')); ?>/#" class="logo">
						<img src="<?php echo e(asset('frontEnd')); ?>/images/icons/logo_ceta.png" alt="IMG-LOGO">
					</a>

					<!-- Menu desktop -->
					<div class="menu-desktop">
						<ul class="main-menu">
							<li>
								<a href="#">A1</a>
								<ul class="sub-menu">
									<li><a href="#">T1 1</a></li>
									<li><a href="#">T2 2</a></li>
									<li><a href="#">T3 3</a></li>
								</ul>
							</li>

							<li>
								<a href="#">A2</a>
							</li>

							<li>
								<a href="#">A3</a>
							</li>

							<li>
								<a href="#">A4</a>
							</li>

							<li>
								<a href="#">A5</a>
							</li>

							<li>
								<a href="#">A6</a>
							</li>
						</ul>
                    </div>
				</nav>
			</div>
		</div>

		<!-- Header Mobile -->
		<div class="wrap-header-mobile">
			<!-- Logo moblie -->
			<div class="logo-mobile">
				<a href="index.html"><img src="<?php echo e(asset('frontEnd')); ?>/images/icons/logo_ceta.png" alt="IMG-LOGO"></a>
			</div>

			<!-- Icon header -->
			<!-- Button show menu -->
			<div class="btn-show-menu-mobile hamburger hamburger--squeeze">
				<span class="hamburger-box">
					<span class="hamburger-inner"></span>
				</span>
			</div>
		</div>


		<!-- Menu Mobile -->
		<div class="menu-mobile">


			<ul class="main-menu-m">
				<li>
					<a href="#">A1</a>
					<ul class="sub-menu-m">
						<li><a href="#">T1 1</a></li>
						<li><a href="#">T2 2</a></li>
						<li><a href="#">T3 3</a></li>
					</ul>
					<span class="arrow-main-menu-m">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</span>
				</li>

				<li>
					<a href="#">A2</a>
				</li>

				<li>
					<a href="#" class="" data-label1="">A3</a>
				</li>

				<li>
					<a href="#">A4</a>
				</li>

				<li>
					<a href="#">A5</a>
				</li>

				<li>
					<a href="#">A6</a>
				</li>
			</ul>
		</div>
<?php /**PATH /Users/zero/Desktop/Internship/TEST-master/www2/resources/views/filepropro/header.blade.php ENDPATH**/ ?>