

<?php $__env->startSection('css_js'); ?>


	<link rel="icon" type="<?php echo e(asset('frontEnd')); ?>/image/png" href="<?php echo e(asset('frontEnd')); ?>/images/icons/favicon.png"/>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/fonts/font-awesome-4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/fonts/iconic/css/material-design-iconic-font.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/fonts/linearicons-v1.0.0/icon-font.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/animate/animate.css">
	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/css-hamburgers/hamburgers.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/animsition/css/animsition.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/select2/select2.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/daterangepicker/daterangepicker.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/slick/slick.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/MagnificPopup/magnific-popup.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/css/util.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/css/main.css">
<!--===============================================================================================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('popo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/zero/Desktop/Internship/TEST-master/www2/resources/views/filepropro/detail_inside.blade.php ENDPATH**/ ?>