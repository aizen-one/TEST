@extends('popo')

@section('css_js')


	<link rel="icon" type="{{ asset('frontEnd') }}/image/png" href="{{ asset('frontEnd') }}/images/icons/favicon.png"/>

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/fonts/font-awesome-4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/fonts/iconic/css/material-design-iconic-font.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/fonts/linearicons-v1.0.0/icon-font.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/animate/animate.css">
	
	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/css-hamburgers/hamburgers.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/animsition/css/animsition.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/select2/select2.min.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/daterangepicker/daterangepicker.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/slick/slick.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/MagnificPopup/magnific-popup.css">

	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/css/util.css">
	<link rel="stylesheet" type="text/css" href="{{ asset('frontEnd') }}/css/main.css">
<!--===============================================================================================-->

@endsection